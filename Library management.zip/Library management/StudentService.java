package studentManagementSystem;

import java.util.List;
import java.util.Scanner;

class StudentService {

	Scanner sc = new Scanner(System.in);

	//ADD STUDENT
	public Student addStudent() {

		Student std = new Student();

		System.out.println("Enter the Student Id : ");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the Student Name :");
		String stdName = sc.nextLine();
		System.out.println("Enter the Student Roll No : ");
		int rollNo = sc.nextInt();
		System.out.println("Enter the Phone No ");
		long phoneNo = sc.nextLong();
		
		std = new Student(id, stdName, rollNo, phoneNo);
		return std;

	}
	//VIEW STUDENTS

	public void getStudents(List<Student> stds) {
		System.out.println(stds);
		//PRINT LIST EVERY THING
	}

	public Student getStudentById(List<Student> stds) {
		//RETRIVE BY ID
		System.out.println("Enter the Student Id for show : ");
		int id = sc.nextInt();
		// FOR EACH 
		for (Student std : stds) {
			if (id == std.getId()) {
				return std;
			}
		}

		return null;
	}

	public List<Student> putStudent(List<Student> students) {
		System.out.println("Enter the Student Id for Update : ");
		int id = sc.nextInt();
		sc.nextLine();
		
		for(Student std : students) {
			if(std.getId()==id) {
				System.out.println("Enter the Student Name :");
				String stdName = sc.nextLine();
				System.out.println("Enter the Student Roll No : ");
				int rollNo = sc.nextInt();
				System.out.println("Enter the Phone No ");
				long phoneNo = sc.nextLong();
				std.setName(stdName);
				std.setPhoneNo(phoneNo);
				std.setRollNo(rollNo);
				
			}
		}
		
		return students;
	}
	
	
	public List<Student> deleteStudent(List<Student> students){

		System.out.println("Enter the Student Id for delete : ");
		int id = sc.nextInt();

		for (Student std : students) {
			if (id == std.getId()) {
				students.remove(std);
				return students;
			}
		}

		return students;
	}
 
}