package studentManagementSystem;


import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


public class UserInterface {

	public static void main(String[] args) {
		List<Student> ll = new LinkedList<Student>();
		Scanner sc = new Scanner(System.in);
		Student std = new Student();

		StudentService service = new StudentService();
		// CRUD 
		while (true) {
			System.out.println("Enter your Choice");
			System.out.println("1 for post Student");
			System.out.println("2 for get All Student");
			System.out.println("3 for get Student By Id ");
			System.out.println(("4 for put Student")); // update Student
			System.out.println("5 for delete Student By Id");
			int key = sc.nextInt();

			if (key == 1) {

				ll.add(service.addStudent());

			} else if (key == 2) {
				service.getStudents(ll);

			} else if (key == 3) {

				Student existStudent = service.getStudentById(ll);
				if (existStudent != null) {
					System.out.println(existStudent);
				} else {
					System.out.println("Student Not Found");
				}

			} else if (key == 4) {
				ll = service.putStudent(ll);

			} else if (key == 5) {
				ll = service.deleteStudent(ll);
			}

		}

	}

}